"""Representações da nota, compartilhadas pela extração e comparação."""
import html
import json
from pathlib import Path

from bs4 import BeautifulSoup


def unwrap_result(data):
    if not isinstance(data, dict):
        raise ValueError("O resultado OCR deve ser um objeto JSON.")
    data = data.get("res", data)
    if not isinstance(data, dict) or not isinstance(data.get("parsing_res_list"), list):
        raise ValueError("Use o JSON completo do PaddleOCR (*_res.json).")
    return data


def table_rows(table):
    """Expande células mescladas mantendo seu texto apenas na origem."""
    grid = {}
    for r, row in enumerate(table.find_all("tr")):
        c = 0
        for cell in row.find_all(["td", "th"], recursive=False):
            while (r, c) in grid:
                c += 1
            height = max(1, int(cell.get("rowspan", 1)))
            width = max(1, int(cell.get("colspan", 1)))
            if height > 1000 or width > 1000:
                raise ValueError("Tabela com rowspan/colspan maior que 1000.")
            for y in range(r, r + height):
                for x in range(c, c + width):
                    grid[y, x] = ""
            grid[r, c] = cell.get_text(" ", strip=True)
            c += width
    if not grid:
        return []
    width = max(c for r, c in grid) + 1
    return [[grid.get((r, c), "") for c in range(width)]
            for r in range(max(r for r, c in grid) + 1)]


def compact_result(raw):
    data = unwrap_result(raw)
    compact = {
        "document": {key: data[key] for key in ("width", "height") if data.get(key)},
        "sections": [],
    }
    texts = []
    for block in data["parsing_res_list"]:
        content = block.get("block_content") or ""
        section = {"type": block.get("block_label") or "text"}
        if block.get("block_bbox") is not None:
            section["bbox"] = block["block_bbox"]
        if section["type"] == "table" and "<table" in content.lower():
            soup = BeautifulSoup(content, "html.parser")
            section["rows"] = table_rows(soup.find("table"))
            texts.extend(text for row in section["rows"] for text in row if text)
        else:
            section["text"] = content
            texts.append(content)
        compact["sections"].append(section)
    covered = "\n".join("".join(text.split()) for text in texts)
    missing = []
    ocr = data.get("overall_ocr_res") or {}
    boxes = ocr.get("rec_boxes") or []
    for i, text in enumerate(ocr.get("rec_texts") or []):
        normalized = "".join(text.split())
        if normalized and normalized not in covered:
            item = {"text": text}
            if i < len(boxes):
                item["bbox"] = boxes[i]
            missing.append(item)
            covered += "\n" + normalized
    if missing:
        compact["unplaced_text"] = missing
    if not any(text.strip() for text in texts) and not missing:
        raise ValueError("O OCR não retornou texto utilizável para esta página.")
    return compact


def md_text(text):
    text = html.escape(text, quote=False).replace("|", "&#124;")
    for char in ("\\", "`", "*", "_", "[", "]", "#"):
        text = text.replace(char, "\\" + char)
    return text.replace("\r\n", "\n").replace("\n", "<br>")


def to_markdown(compact):
    parts = []
    for section in compact["sections"]:
        if "rows" in section:
            rows = section["rows"]
            if rows:
                width = max(map(len, rows))
                parts.extend(["| " + " | ".join([""] * width) + " |",
                              "| " + " | ".join(["---"] * width) + " |"])
                for row in rows:
                    cells = row + [""] * (width - len(row))
                    parts.append("| " + " | ".join(md_text(t) for t in cells) + " |")
        else:
            prefix = "## " if "title" in section["type"] else ""
            parts.append(prefix + md_text(section["text"]))
        parts.append("")
    if compact.get("unplaced_text"):
        parts.append("## Outros campos\n")
        parts.extend("- " + md_text(item["text"]) for item in compact["unplaced_text"])
    return "\n".join(parts).strip() + "\n"


def to_html(compact):
    parts = []
    for section in compact["sections"]:
        if "rows" in section:
            rows = ["<tr>" + "".join("<td>" + html.escape(t) + "</td>" for t in row)
                    + "</tr>" for row in section["rows"]]
            parts.append("<table>" + "".join(rows) + "</table>")
        else:
            tag = "h2" if "title" in section["type"] else "p"
            parts.append(f"<{tag}>" + html.escape(section["text"]) + f"</{tag}>")
    if compact.get("unplaced_text"):
        parts.append("<h2>Outros campos</h2><ul>" + "".join(
            "<li>" + html.escape(item["text"]) + "</li>"
            for item in compact["unplaced_text"]) + "</ul>")
    return ('<!DOCTYPE html>\n<html lang="pt-BR"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width, initial-scale=1">'
            '<title>Nota fiscal</title><style>body{font-family:Arial,sans-serif;margin:24px}'
            'table{border-collapse:collapse;width:100%;margin:16px 0}'
            'td{border:1px solid #777;padding:5px;overflow-wrap:anywhere}'
            'p,td{white-space:pre-wrap}@media print{body{margin:0}}</style></head><body>\n'
            + "\n".join(parts) + "\n</body></html>\n")


def write_intermediates(raw, destination):
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    compact = compact_result(raw)
    (destination / "compact_intermediate.json").write_text(
        json.dumps(compact, ensure_ascii=False, indent=2), encoding="utf-8")
    (destination / "invoice.md").write_text(to_markdown(compact), encoding="utf-8")
    (destination / "invoice.html").write_text(to_html(compact), encoding="utf-8")
    return compact
