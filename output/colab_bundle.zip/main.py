"""Extração local com PaddleOCR: python main.py --help."""
import argparse
import json
from pathlib import Path
import sys

from invoice_formats import unwrap_result, write_intermediates

BASE_DIR = Path(__file__).resolve().parent


def simplify_result(res):
    data = unwrap_result(res.json)
    return [{"type": b.get("block_label"), "bbox": b.get("block_bbox"),
             "content": b.get("block_content")} for b in data["parsing_res_list"]]


def extract(input_path, output_dir, *, image_preprocess=False, cpu_threads=2):
    input_path, output_dir = Path(input_path), Path(output_dir)
    if not input_path.is_file():
        raise ValueError(f"Arquivo não encontrado: {input_path}")
    from paddleocr import PPStructureV3

    pipeline = PPStructureV3(
        lang="pt", device="cpu",
        use_doc_orientation_classify=image_preprocess,
        use_doc_unwarping=image_preprocess,
        enable_mkldnn=False, cpu_threads=cpu_threads,
        use_formula_recognition=False, use_chart_recognition=False,
        use_seal_recognition=False, use_table_recognition=True,
    )
    output_dir.mkdir(parents=True, exist_ok=True)
    pages = []
    for i, res in enumerate(pipeline.predict(str(input_path.resolve()))):
        page_dir = output_dir / f"pagina_{i + 1:03d}"
        page_dir.mkdir(parents=True, exist_ok=True)
        raw = unwrap_result(res.json)
        res.save_to_json(save_path=str(page_dir))
        res.save_to_markdown(save_path=str(page_dir))
        res.save_to_html(save_path=str(page_dir))
        (page_dir / "layout.json").write_text(
            json.dumps(simplify_result(res), ensure_ascii=False, indent=2), encoding="utf-8")
        write_intermediates(raw, page_dir)
        pages.append(raw)
        print(f"Página {i + 1}: {page_dir.resolve()}", flush=True)
    if not pages:
        raise ValueError("O PaddleOCR não retornou páginas.")
    return pages


def positive_int(value):
    number = int(value)
    if number < 1:
        raise argparse.ArgumentTypeError("Informe um inteiro maior que zero.")
    return number


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=BASE_DIR / "input/img_1.jpg")
    parser.add_argument("--output", type=Path, default=BASE_DIR / "output/extracao")
    parser.add_argument("--image-preprocess", choices=("on", "off", "both"), default="off",
                        help="Correção de orientação e deformação antes do OCR (padrão: off).")
    parser.add_argument("--cpu-threads", type=positive_int, default=2)
    args = parser.parse_args(argv)
    modes = ("off", "on") if args.image_preprocess == "both" else (args.image_preprocess,)
    try:
        for mode in modes:
            extract(args.input, args.output / mode, image_preprocess=mode == "on",
                    cpu_threads=args.cpu_threads)
    except Exception as exc:
        print(f"Erro na extração: {exc}\nConfira as dependências e o acesso aos modelos do PaddleOCR.",
              file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
